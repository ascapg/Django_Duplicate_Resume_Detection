from django.urls import path
from . import views

urlpatterns = [
path('', views.show),
path('disp_company',views.company_details, name='disp_company'),
]
