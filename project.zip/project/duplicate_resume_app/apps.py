from django.apps import AppConfig


class DuplicateResumeAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'duplicate_resume_app'
